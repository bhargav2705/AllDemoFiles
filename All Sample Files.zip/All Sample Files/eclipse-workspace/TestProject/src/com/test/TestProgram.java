package com.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Java is a Programming language";
	    String[] newStr=str.split("");
	    System.out.println(newStr.length);
		
		
	}

}
