package com.test;

public class LLPractice {
	
class Node{
		int val;
		Node next;
		public Node(int val)
		{
			this.val=val;
		}
	}

Node head=null;
Node tail=null;

public void addNewNodeEnd(int val)
{
	Node n= new Node(val);
	if(head==null && tail==null)
	{
		head=n;
		tail=n;
	}
	else
	{
		tail.next=n;
		n.next=null;
		tail=n;
	}
}

public void addNodeAtFirst(int val)
{
	 Node newNode= new Node(val);
	 newNode.next=head;
	 head=newNode;

}

public void addNodeatIndex(int val,int index)
{
      
	Node currentNode=head;
	int count=1;
	while (currentNode!=null && count!=index-1)
	{
		currentNode=currentNode.next;
		count++;
	}
	Node newNode=new Node(val);
	Node temp=currentNode.next;
	currentNode.next=newNode;
	newNode.next=temp;
}

public void printLinkedList()
{
	Node current=head;
	while(current!=null)
	{
		System.out.println(current.val);
		current=current.next;
	}
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LLPractice lp=new LLPractice();
		lp.addNewNodeEnd(10);
		//lp.printLinkedList();
		lp.addNewNodeEnd(20);
		//lp.printLinkedList();
		lp.addNewNodeEnd(30);
		lp.addNodeAtFirst(1000);
		lp.addNewNodeEnd(500);
		lp.printLinkedList();
		System.out.println("------------------------------------------------");
		lp.addNodeatIndex(2000, 4);
		lp.printLinkedList();
	}

}
