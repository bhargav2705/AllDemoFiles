package com.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="abbcccd";
		String newString="";
		
		//Exp o/p==ad
		
		char chr[]=s.toCharArray();
		
		HashMap<Character,Integer> hm=new HashMap <Character,Integer>();
		
		Integer count=1;
		
		for (int i=0;i<s.length();i++)
		{
			if(hm.containsKey(chr[i]))
			{
				hm.put(chr[i], count+1);
			}
			else
			{
				hm.put(chr[i], count);
			}
		}
		
		for(Entry<Character, Integer> entry: hm.entrySet())
				
   {
		
		if (entry.getValue()==1)
		{
			Character lc=entry.getKey();
			newString=newString + lc.toString();
			
		
			
		}
	}
		System.out.println(newString);
	}
	
}
