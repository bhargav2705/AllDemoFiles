package com.test;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String day="Thursday ";
		String newDay= day + "is love day";
		
		//System.out.println(newDay.indexOf("day"));
		int newIndex=newDay.indexOf("day");
		System.out.println("New index: " +newIndex);
		int count=0;
		
		while(newIndex!=-1)
		{
			count++;
			newIndex=newDay.indexOf("day", newIndex+1);
		}
        System.out.println("No.of occurences of day is:" +count);
	
}
}